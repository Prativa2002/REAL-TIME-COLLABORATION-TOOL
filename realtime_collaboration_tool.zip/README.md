# Real-Time Collaborative Note-Taking Tool

This is a simple real-time collaborative text editor using WebSockets (Socket.IO) and Node.js.

## Features

- Multiple users can edit the same document in real-time.
- WebSocket-based synchronization using Socket.IO.
- Minimal frontend UI with textarea.

## How to Run

1. Make sure Node.js is installed.
2. Install dependencies:
   ```bash
   npm install express socket.io
   ```
3. Run the server:
   ```bash
   node server.js
   ```
4. Open `http://localhost:3000` in multiple browser windows to test collaboration.

## Folder Structure

```
project/
├── server.js
├── README.md
└── public/
    ├── index.html
    ├── style.css
    └── script.js
```